package com.iexpertos.queryparser.tests;

import static org.junit.jupiter.api.Assertions.*;
import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;
import org.junit.jupiter.api.Test;

class QueryParserShould {

	@Test
	void test() {
		assertThat(true, is(true));
	}

}
